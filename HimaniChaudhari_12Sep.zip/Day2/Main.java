package starhealth.Day2;

import starhealth.Day1.Primitive;

public class Main extends Primitive {

	public static void main(String[] args) {
		
		Main m = new Main();
		System.out.println(m.j);

		Product milk = new Product(2000,"10/09/2022","13/09/2022",50,2);
		System.out.println(milk.getProductId()+" "+milk.getManufacturingDate()+" "+milk.getExpiryDate()+" "+milk.getPrice()+" "+milk.getQuantity());
	
		//this will print productId as 2000 because we have set it as static variable.
		Product juice = new Product();// this will print the default values of variable(2000 null null 0 0).
		
		juice.setManufacturingDate("5/9/2022");
		juice.setExpiryDate("7/9/2022");
		juice.setPrice(60);
		juice.setQuantity(3);
		System.out.println(juice.getManufacturingDate()+" "+juice.getExpiryDate()+" "+juice.getPrice()+" "+juice.getQuantity());

	}

}
