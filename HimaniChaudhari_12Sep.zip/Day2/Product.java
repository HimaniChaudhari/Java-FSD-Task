package starhealth.Day2;

public class Product {

	private String manufacturingDate;
	private String expiryDate;
	private int price;
	private int quantity;
    public static int productId;
	
		
	public Product() {
		super();
		// this will print the default values of variables.
		System.out.println(this.productId+" "+this.manufacturingDate+" "+this.expiryDate+" "+this.price+" "+this.quantity);
	}

	public Product(int productId, String manufacturingDate, String expiryDate, int price, int quantity) {
		super();
		this.productId =productId;
		this.manufacturingDate = manufacturingDate;
		this.expiryDate = expiryDate;
		this.price = price;
		this.quantity = quantity;
	}
	
	
	public static int getProductId() {
		return productId;
	}

	public static void setProductId(int productId) {
		Product.productId = productId;
	}

	public String getManufacturingDate() {
		return manufacturingDate;
	}
	public void setManufacturingDate(String manufacturingDate) {
		this.manufacturingDate = manufacturingDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
