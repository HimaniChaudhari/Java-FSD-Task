package com.training.multithreading;

public class MainDemo {

	public static void main(String argvs[]) {

		ThreadDemo t1 = new ThreadDemo();
		ThreadDemo t2 = new ThreadDemo();
		ThreadDemo t3 = new ThreadDemo();

		t1.start();

		try {
			System.out.println("The current thread: " + Thread.currentThread().getName());

			t1.join();
		}

		catch (Exception e) {
			System.out.println("The exception has been caught " + e);
		}

		t2.start();

		try {
			System.out.println("The current thread name is: " + Thread.currentThread().getName());
			t2.join();
		}

		catch (Exception e) {
			System.out.println("The exception has been caught " + e);
		}

		t3.start();
	}
}