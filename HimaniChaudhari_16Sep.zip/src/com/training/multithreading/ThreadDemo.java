package com.training.multithreading;

public class ThreadDemo extends Thread {
	public void run()  
	{  
	for (int j = 0; j < 5; j++)  
	{  
	try  
	{  
	 
	Thread.sleep(1000);  
	System.out.println("The current thread name is: " + Thread.currentThread().getName());  
	}  
	  
	catch(Exception e)  
	{  
	System.out.println("The exception has been caught: " + e);  
	}  
	System.out.println( j );  
	}  
	}  
}
