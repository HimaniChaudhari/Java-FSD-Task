package com.training.multithreading;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Collection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Object> list  = new ArrayList<Object>();
		list.add("Dev");
		list.add("Priya");
		list.add("Charu");
		list.add("Appu");
		System.out.println(list);
		System.out.println("Size of list: " + list.size());
		System.out.println("Removing 2nd index....");
		list.remove(2);
		System.out.println("List:" + list);
		Iterator<Object> it = list.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		List<Object> linkedlist = new LinkedList<Object>();
		linkedlist.add("kiwi");
		linkedlist.add(10);
		linkedlist.add(10.2);
		linkedlist.add(2,"jackfruit");
		System.out.println(linkedlist);
		System.out.println(linkedlist.get(3));
	}

}
