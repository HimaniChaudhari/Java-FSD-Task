package com.training.exception;

public class atmException extends Exception {

	public atmException(String exception){
		super(exception);
	}
}
