package com.training.exception;

public class Test {

	public static void main(String[] args) {
		long[]userPin = {121314,989678,456782,268190,189608};
		long[]acceptedPin = {121314,456782,189608};
		int userPinCodeLen = userPin.length;
		int acceptedLen = acceptedPin.length;
		
		for(int i=0;i<userPinCodeLen;i++) {
			int flag = 0;
			for(int j=0;j<acceptedLen;j++) {
				if (userPin[i]==acceptedPin[j]) {
					flag=1;
					break;
				}
			}
			if (flag==0) {
				try {
					throw new atmException("Invalid ATM Pin "+userPin[i]);
				}
				catch(Exception e) {
					System.err.println(e);
				}
			}
			else {
				System.out.println("ATM Pin "+userPin[i]+" accepted.");
			}
		}
	}
}
