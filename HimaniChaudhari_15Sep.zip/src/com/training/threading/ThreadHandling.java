package com.training.threading;

public class ThreadHandling extends Thread {

	public static void main(String[] args) {
		ThreadHandling t1 = new ThreadHandling();
		t1.setPriority(2);
		t1.setName("Thread 1 started.");
		t1.start();
		
		ThreadHandling t2 = new ThreadHandling();
		t2.setName("Thread 2 started.");
		t2.start();
		
	}
	
	@Override
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println(Thread.currentThread().getPriority());
			System.out.println(Thread.currentThread().getName());
		}
	}

}
