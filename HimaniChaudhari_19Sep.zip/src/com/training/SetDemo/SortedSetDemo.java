package com.training.SetDemo;

import java.util.SortedSet;
import java.util.TreeSet;

public class SortedSetDemo {

	public static void main(String[] args) {
		SortedSet<String> sortedSet = new TreeSet<String>();
		sortedSet.add("Pineapple");
		sortedSet.add("Jackfrut");
		sortedSet.add("Grape");
		sortedSet.add("Orange");
		System.out.println(sortedSet.first());
		System.out.println(sortedSet.last());
		sortedSet.headSet("Apple");
		System.out.println(sortedSet);
	}

}
