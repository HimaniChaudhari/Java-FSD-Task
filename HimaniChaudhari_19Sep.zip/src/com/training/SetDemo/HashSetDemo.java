package com.training.SetDemo;

import java.util.HashSet;

public class HashSetDemo {

	public static void main(String[] args) {
		HashSet<Integer> set = new HashSet<Integer>();
		set.add(103);
		set.add(104);
		set.add(105);
		set.add(106);
		set.add(107);
		set.add(null);
		set.add(103);
		System.out.println(set);
		
		HashSet<Employee> setEmp = new HashSet<Employee>();
		setEmp.add(new Employee(101,"himani",10000.0));
		setEmp.add(new Employee(102,"pooja",17000.0));
		setEmp.add(new Employee(100,"ashi",12000.0));
		setEmp.add(new Employee(104,"ajay",10000.0));
		System.out.println(setEmp);

	}

}
