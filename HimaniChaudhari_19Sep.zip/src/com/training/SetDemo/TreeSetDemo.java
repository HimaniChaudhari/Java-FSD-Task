package com.training.SetDemo;

import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		TreeSet<Employee> tree = new TreeSet<Employee>(new MyComparator());
		tree.add(new Employee(201,"himani",12000.0));
		tree.add(new Employee(208,"vijay",22000.0));
		tree.add(new Employee(203,"ajay",17000.0));
		tree.add(new Employee(205,"pooja",12000.0));
		
		System.out.println(tree);
	}

}
