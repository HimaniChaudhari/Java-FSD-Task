package com.training.SetDemo;

import java.util.LinkedHashSet;

public class LinkedHashSetDemo {

	public static void main(String[] args) {
		LinkedHashSet<Employee> setEmp = new LinkedHashSet<Employee>();
		setEmp.add(new Employee(211,"himani",20000.0));
		setEmp.add(new Employee(209,"pooja",22000.0));
		setEmp.add(new Employee(214,"avi",21000.0));
		setEmp.add(new Employee(213,"ajay",22500.0));
		System.out.println(setEmp);

	}

}
