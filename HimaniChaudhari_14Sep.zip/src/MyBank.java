public class MyBank {

}
class SBI extends MyBank {
    private String IFSC;
    private int AccNumber;
    private String Name;

    public SBI(String IFSC, int AccNumber, String Name) {
        this.IFSC = IFSC;
        this.AccNumber = AccNumber;
        this.Name = Name;
    }

    public SBI() {

    }

    static void deposite() {
        System.out.println("Deposited from SBI");

    }

    public String getIFSC() {
        return IFSC;
    }

    public void setIFSC(String IFSC) {
        this.IFSC = IFSC;
    }

    public int getAccNumber() {
        return AccNumber;
    }

    public void setAccNumber(int accNumber) {
        AccNumber = accNumber;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    @Override
    public String toString() {
        return "SBI{" +
                "IFSC='" + IFSC + '\'' +
                ", AccNumber=" + AccNumber +
                ", Name='" + Name + '\'' +
                '}';
    }
    @Override
    public int hashCode() {
        return AccNumber;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        SBI other = (SBI) obj;
        return AccNumber == other.AccNumber;
    }




    public static void main(String[] args) {
        SBI s1 = new SBI("SBIN000777", 12684578, "himani");
        System.out.println(s1);
        SBI s2= new SBI("SBIN000777",112237874,"kunal");
        System.out.println(s2);

        System.out.println(s1==s2);

        System.out.println(s1.equals(s2));

        System.out.println(s1.hashCode());
        System.out.println(s2.hashCode());


        deposite();

    }
}

