public class Main {
    public static void main(String[] args) {
        SBI s = new SBI("SBIN000777", 122564578, "himani");

        System.out.println("Account holder is" + s.getName());
        System.out.println("IFSC code of your bank" + s.getIFSC());
        System.out.println("your Account Number is" + s.getAccNumber());

    }
}