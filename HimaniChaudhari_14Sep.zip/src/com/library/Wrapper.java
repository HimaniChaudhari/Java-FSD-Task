package com.library;

public class Wrapper {
    public static void main(String[] args) {

        int n1= 20;
        String s= "20";
        Integer i = new Integer(20);



        Integer j = new Integer("20");

        String s1 = i.toString();

    }

}
