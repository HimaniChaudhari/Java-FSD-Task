package com.library;

public class StringDemo {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        String s1 = "Himani";
        String s2 = "Himani";
        String s3 = new String("Himani");
        String s4 = new String("Himani");
        System.out.println(s1);
        System.out.println(s2);

        s2 = s2.concat("Chaudhari");
        System.out.println(s2);

        String str1 = new String("H");
        String str2 = new String("H");

        System.out.println(str1.compareTo(str2));

        StringBuffer sb1 = new StringBuffer("Himani");
        sb1.append("Chaudhari");
        System.out.println(sb1.reverse());
        System.out.println(sb1);

        System.out.println(sb1.replace(0, 1, "B"));


    }

}
