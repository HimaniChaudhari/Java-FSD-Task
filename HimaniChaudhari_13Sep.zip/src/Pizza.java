
public class Pizza extends Food{
    public String type = "Fast Food";

    public String Base = "Deep Pan Crust";
}
