package starhealth.Day1;

public class Primitive {
	protected int j =20;

	public static void main(String[] args) {

        byte b = 100;
        System.out.println("byte b= " + b);
 
        short s = 100;
        System.out.println("short s= " + s);
 
        int i = 100;
        System.out.println("int i= " + i);
 
        long l = 100;
        System.out.println("long l= " + l);
        
        double d =100;
        System.out.println("double d= "+ d);
        long l1 = (long) d;
        System.out.println("long l1= "+l1);
        int i1 =(int) l1;
        System.out.println("int i1= "+i1);
        
        char ch = 'S';
        System.out.println("char ch= "+ ch);
	}

}
