package com.java8;

@FunctionalInterface
public interface MyInterface {
	
	
	public void display (String name); //consumer
	//public String();

}
